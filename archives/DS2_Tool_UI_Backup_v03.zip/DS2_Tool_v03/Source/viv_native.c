#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <commctrl.h>
#include <stdio.h>
#include <stdint.h>
#include <wchar.h>
#include <stdlib.h>
#include <string.h>
#include "payload.h"
#define BS (8*1024*1024)
#define WM_STAGE (WM_APP+1)
#define WM_DONE (WM_APP+2)
static HWND mainwin,inbox,outbox,bar,statusbox,startbtn,cancelbtn,binbtn,boutbtn,autobox,helpbox;
static int auto_install=1;
static wchar_t backup_path[32768];
static volatile LONG stopflag=0;
static int busy=0;
static wchar_t inputpath[32768],outputpath[32768];
static const wchar_t* stages[]={L"正在定位资源…",L"正在复制原始 VIV…",L"正在写入并校验资源…"};
static const unsigned char* olddata[2]={payload_0_original,payload_1_original};
static const unsigned char* newdata[2]={payload_0_new,payload_1_new};
static DWORD sizes[2]={sizeof(payload_0_original),sizeof(payload_1_original)};
typedef struct {uint64_t offset;int state;int count;} Hit;
static int err(wchar_t* e,const wchar_t* s){wcscpy(e,s);return 0;}
static void progress(int stage,uint64_t done,uint64_t total){if(mainwin)PostMessageW(mainwin,WM_STAGE,stage,total?(LPARAM)(done*100/total):0);}
static int seekto(HANDLE f,uint64_t pos){LARGE_INTEGER n;n.QuadPart=pos;return SetFilePointerEx(f,n,NULL,FILE_BEGIN);}
static int readexact(HANDLE f,void* b,DWORD size){DWORD n;return ReadFile(f,b,size,&n,NULL)&&n==size;}
static int writeexact(HANDLE f,const void* b,DWORD size){DWORD n;return WriteFile(f,b,size,&n,NULL)&&n==size;}
static int samefile(const wchar_t*a,const wchar_t*b){wchar_t x[32768],y[32768];return GetFullPathNameW(a,32768,x,NULL)&&GetFullPathNameW(b,32768,y,NULL)&&_wcsicmp(x,y)==0;}
static size_t find_anchor(const unsigned char* data,size_t len,size_t start,const unsigned char* pattern){
 size_t skip[256];for(int i=0;i<256;i++)skip[i]=64;for(int i=0;i<63;i++)skip[pattern[i]]=63-i;
 size_t p=start;while(p+64<=len){if(data[p+63]==pattern[63]&&memcmp(data+p,pattern,64)==0)return p;p+=skip[data[p+63]];}return (size_t)-1;
}
/* No VIV header interpretation: accept only complete byte-identical resource copies.
   Equal-length writes preserve archive offsets and all other bytes. */
static int merge_file(const wchar_t*src,const wchar_t*dst,wchar_t*error){
 HANDLE in=INVALID_HANDLE_VALUE,verify=INVALID_HANDLE_VALUE,out=INVALID_HANDLE_VALUE;
 unsigned char*buf=NULL,*candidate=NULL;wchar_t*temp=NULL;int owns=0,ok=0;LARGE_INTEGER total;
 Hit hit[2]={{0}};DWORD got;uint64_t done=0;size_t carry=0;
 if(samefile(src,dst))return err(error,L"输出不能与原始文件相同。请选择另存路径。");
 if(GetFileAttributesW(dst)!=INVALID_FILE_ATTRIBUTES)return err(error,L"输出文件已存在，请选择新的文件名。");
 temp=malloc((wcslen(dst)+16)*sizeof(wchar_t));if(!temp)return err(error,L"内存不足。");wcscpy(temp,dst);wcscat(temp,L".partial");
 in=CreateFileW(src,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_SEQUENTIAL_SCAN,NULL);
 if(in==INVALID_HANDLE_VALUE){err(error,L"无法读取原始 VIV。请关闭占用该文件的修改工具。");goto end;}
 if(!GetFileSizeEx(in,&total)||total.QuadPart<=0){err(error,L"原始文件大小无效。");goto end;}
 verify=CreateFileW(src,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 if(verify==INVALID_HANDLE_VALUE){err(error,L"无法建立校验读取句柄。");goto end;}
 buf=malloc(BS+64);candidate=malloc(sizes[0]>sizes[1]?sizes[0]:sizes[1]);
 if(!buf||!candidate){err(error,L"内存不足。");goto end;}
 while(ReadFile(in,buf+carry,BS,&got,NULL)){
  if(!got)break;if(InterlockedCompareExchange(&stopflag,0,0)){err(error,L"已取消。原始文件未修改。");goto end;}
  size_t n=carry+got;uint64_t base=done-carry;
  for(int k=0;k<2;k++){
   int anchors=memcmp(olddata[k],newdata[k],64)==0?1:2;
   for(int j=0;j<anchors;j++){
    const unsigned char*anchor=j?newdata[k]:olddata[k];size_t p=0;
    while((p=find_anchor(buf,n,p,anchor))!=(size_t)-1){
     uint64_t off=base+p;p++;
     if((hit[k].count&&hit[k].offset==off)||off+sizes[k]>(uint64_t)total.QuadPart)continue;
     if(!seekto(verify,off)||!readexact(verify,candidate,sizes[k])){err(error,L"扫描资源时读取失败。");goto end;}
     int state=memcmp(candidate,olddata[k],sizes[k])==0?1:(memcmp(candidate,newdata[k],sizes[k])==0?2:0);
     if(state){hit[k].offset=off;hit[k].state=state;hit[k].count++;if(hit[k].count>1){err(error,L"同一资源存在多个完全匹配位置，已停止以避免改错。");goto end;}}
    }
   }
  }
  done+=got;carry=n<63?n:63;memmove(buf,buf+n-carry,carry);progress(0,done,total.QuadPart);
 }
 if(done!=(uint64_t)total.QuadPart){err(error,L"原始 VIV 扫描不完整，请检查读取错误。");goto end;}
 for(int k=0;k<2;k++)if(hit[k].count!=1){err(error,k==0?L"未找到完全匹配的 8CA715C3 语言资源。请选择与上传资源一致的原始 bigfile0.viv。":L"未找到完全匹配的字体资源。请选择与上传资源一致的原始 bigfile0.viv。");goto end;}
 if(hit[0].state==2&&hit[1].state==2){err(error,L"此 VIV 已包含本版“新游戏”修改，无需再次合并。");goto end;}
 if(hit[0].offset<hit[1].offset+sizes[1]&&hit[1].offset<hit[0].offset+sizes[0]){err(error,L"资源范围重叠，已停止。");goto end;}
 out=CreateFileW(temp,GENERIC_READ|GENERIC_WRITE,0,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL);
 if(out==INVALID_HANDLE_VALUE){err(error,L"无法创建输出临时文件。请检查空间、权限，或已有同名 .partial 文件。");goto end;}owns=1;
 if(!seekto(in,0)){err(error,L"无法重新读取原始文件。");goto end;}done=0;
 while(ReadFile(in,buf,BS,&got,NULL)){
  if(!got)break;if(InterlockedCompareExchange(&stopflag,0,0)){err(error,L"已取消。原始文件未修改。");goto end;}
  if(!writeexact(out,buf,got)){err(error,L"写入失败，请检查磁盘空间和连接。");goto end;}done+=got;progress(1,done,total.QuadPart);
 }
 if(done!=(uint64_t)total.QuadPart){err(error,L"原文件未完整复制。");goto end;}
 for(int k=0;k<2;k++){
  if(!seekto(out,hit[k].offset)||!writeexact(out,newdata[k],sizes[k])){err(error,L"资源回填失败。");goto end;}
 }
 if(!FlushFileBuffers(out)){err(error,L"保存输出文件失败。");goto end;}
 LARGE_INTEGER result;if(!GetFileSizeEx(out,&result)||result.QuadPart!=total.QuadPart){err(error,L"输出文件大小不匹配。");goto end;}
 for(int k=0;k<2;k++){
  if(!seekto(out,hit[k].offset)||!readexact(out,candidate,sizes[k])||memcmp(candidate,newdata[k],sizes[k])){err(error,L"输出资源逐字节校验失败。");goto end;}
 }
 if(InterlockedCompareExchange(&stopflag,0,0)){err(error,L"已取消。原始文件未修改。");goto end;}
 CloseHandle(out);out=INVALID_HANDLE_VALUE;
 if(!MoveFileExW(temp,dst,MOVEFILE_WRITE_THROUGH)){err(error,L"输出文件发布失败。请检查目标是否已存在或无写入权限。");goto end;}
 owns=0;ok=1;progress(2,100,100);
end:
 if(out!=INVALID_HANDLE_VALUE)CloseHandle(out);if(verify!=INVALID_HANDLE_VALUE)CloseHandle(verify);if(in!=INVALID_HANDLE_VALUE)CloseHandle(in);
 if(owns)DeleteFileW(temp);free(buf);free(candidate);free(temp);return ok;
}
static int install_generated(const wchar_t*src,const wchar_t*dst,wchar_t*backup,wchar_t*error){
 SYSTEMTIME t;GetLocalTime(&t);wchar_t suffix[128];int available=0;
 if(wcslen(src)>32500)return err(error,L"原文件路径过长，无法生成备份名称。已保留生成的输出。");
 for(int i=0;i<1000;i++){
  swprintf(suffix,128,L".original.%04d%02d%02d_%02d%02d%02d_%03d.bak",t.wYear,t.wMonth,t.wDay,t.wHour,t.wMinute,t.wSecond,i);
  wcscpy(backup,src);wcscat(backup,suffix);
  if(GetFileAttributesW(backup)==INVALID_FILE_ATTRIBUTES){available=1;break;}
 }
 if(!available)return err(error,L"无法分配唯一备份文件名。原文件与生成文件均未修改。");
 if(!MoveFileExW(src,backup,MOVEFILE_WRITE_THROUGH))return err(error,L"原文件自动改名失败。请检查目录权限或文件占用；原文件和生成文件均已保留。");
 if(!MoveFileExW(dst,src,MOVEFILE_WRITE_THROUGH)){
  if(MoveFileExW(backup,src,MOVEFILE_WRITE_THROUGH))return err(error,L"自动替换失败，已恢复原文件名称。生成文件已保留；请将输出位置选在原文件同一磁盘后重试。");
  swprintf(error,4096,L"自动替换失败，原文件已保留在以下备份位置，但无法恢复原名：\n%ls\n请手动将备份恢复为原文件名。生成文件仍保留。",backup);return 0;
 }
 return 1;
}
static DWORD WINAPI worker(LPVOID unused){
 wchar_t*message=calloc(1,4096*sizeof(wchar_t));WIN32_FILE_ATTRIBUTE_DATA before,after;
 int have_before=GetFileAttributesExW(inputpath,GetFileExInfoStandard,&before);
 int ok=merge_file(inputpath,outputpath,message);backup_path[0]=0;
 if(ok&&auto_install){
  if(InterlockedCompareExchange(&stopflag,0,0))ok=err(message,L"已取消自动安装。原文件未修改，已生成的修改版保留在输出路径。");
  else if(!have_before||!GetFileAttributesExW(inputpath,GetFileExInfoStandard,&after)||
    before.nFileSizeHigh!=after.nFileSizeHigh||before.nFileSizeLow!=after.nFileSizeLow||
    CompareFileTime(&before.ftLastWriteTime,&after.ftLastWriteTime)!=0)
    ok=err(message,L"源文件信息发生变化，已停止自动安装；原文件和生成文件均保留。");
  else ok=install_generated(inputpath,outputpath,backup_path,message);
 }
 PostMessageW(mainwin,WM_DONE,ok,(LPARAM)message);return 0;
}
static void choosein(void){OPENFILENAMEW o={0};wchar_t p[32768]={0};o.lStructSize=sizeof(o);o.hwndOwner=mainwin;o.lpstrFilter=L"VIV 文件\0*.viv\0所有文件\0*.*\0";o.lpstrFile=p;o.nMaxFile=32768;o.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;
 if(GetOpenFileNameW(&o)){if(wcslen(p)>32500){MessageBoxW(mainwin,L"路径过长，请将文件移至较短路径。",L"路径检查",MB_OK);return;}SetWindowTextW(inbox,p);wchar_t*d=wcsrchr(p,L'.');if(d)wcscpy(d,L"_zh.viv");else wcscat(p,L"_zh.viv");SetWindowTextW(outbox,p);}}
static void chooseout(void){OPENFILENAMEW o={0};wchar_t p[32768]=L"bigfile0_zh.viv";o.lStructSize=sizeof(o);o.hwndOwner=mainwin;o.lpstrFilter=L"VIV 文件\0*.viv\0";o.lpstrFile=p;o.nMaxFile=32768;o.lpstrDefExt=L"viv";o.Flags=OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;if(GetSaveFileNameW(&o))SetWindowTextW(outbox,p);}
static HWND control(const wchar_t*cls,const wchar_t*txt,DWORD style,int x,int y,int w,int h,int id){HWND a=CreateWindowExW(0,cls,txt,WS_CHILD|WS_VISIBLE|style,x,y,w,h,mainwin,(HMENU)(INT_PTR)id,GetModuleHandle(NULL),NULL);SendMessageW(a,WM_SETFONT,(WPARAM)GetStockObject(DEFAULT_GUI_FONT),TRUE);return a;}
static void setbusy(int b){busy=b;EnableWindow(inbox,!b);EnableWindow(outbox,!b);EnableWindow(binbtn,!b);EnableWindow(boutbtn,!b);EnableWindow(startbtn,!b);EnableWindow(autobox,!b);EnableWindow(cancelbtn,b);}
static LRESULT CALLBACK proc(HWND w,UINT msg,WPARAM wp,LPARAM lp){switch(msg){
 case WM_CREATE:
  mainwin=w;control(L"STATIC",L"Switch 死亡空间2 xbox360版 汉化工具",0,24,18,740,28,0);
  control(L"STATIC",L"工具 v0.3  |  当前内置范围：新游戏菜单（非完整汉化）",0,24,50,740,24,0);
  control(L"STATIC",L"原始 VIV",0,24,88,740,20,0);inbox=control(L"EDIT",L"",WS_BORDER|ES_AUTOHSCROLL,24,112,630,27,0);binbtn=control(L"BUTTON",L"选择…",0,666,112,90,27,101);
  control(L"STATIC",L"生成文件（自动安装时用于暂存；需与原文件位于同一磁盘）",0,24,153,740,20,0);outbox=control(L"EDIT",L"",WS_BORDER|ES_AUTOHSCROLL,24,177,630,27,0);boutbtn=control(L"BUTTON",L"选择…",0,666,177,90,27,102);
  autobox=control(L"BUTTON",L"自动备份并安装：原文件改名保留，修改版使用原文件名",BS_AUTOCHECKBOX,24,220,730,24,105);SendMessageW(autobox,BM_SETCHECK,BST_CHECKED,0);
  bar=control(PROGRESS_CLASSW,L"",0,24,258,732,20,0);SendMessageW(bar,PBM_SETRANGE,0,MAKELPARAM(0,100));
  statusbox=control(L"STATIC",L"请选择与上传资源一致的 Disc 1 或 Disc 2 原始 bigfile0.viv。",0,24,291,732,35,0);
  startbtn=control(L"BUTTON",L"开始合并",0,24,335,160,32,103);cancelbtn=control(L"BUTTON",L"取消",0,196,335,85,32,104);EnableWindow(cancelbtn,FALSE);
  control(L"STATIC",L"详细使用说明（可滚动、选择和复制）",0,24,389,732,22,0);
  helpbox=control(L"EDIT",L"",WS_BORDER|ES_MULTILINE|ES_READONLY|ES_AUTOVSCROLL|WS_VSCROLL,24,417,732,230,0);
  SetWindowTextW(helpbox,
   L"【当前补丁状态】\r\n工具升级不等于翻译完成。此 EXE 内置的仍是“新游戏”菜单和对应字形，不是完整版。未完成的中文初稿没有加入补丁。“新游戏”菜单已通过用户实机截图验证；其他翻译尚未完成。\r\n\r\n"
   L"【一、选择文件】\r\n选择从该盘游戏目录取得的完整 bigfile0.viv，不要选择 ZIP、8CA715C3、字体 STR 或此前解出的单独资源。原文件路径不能与生成文件路径相同。生成位置需要足够空间容纳整份 VIV。\r\n\r\n"
   L"【二、自动备份并安装】\r\n保持上方复选框勾选，点击“开始合并”。程序先扫描并验证资源，在新文件中完成等长回填并校验。全部成功后，原文件自动改名为 bigfile0.viv.original.日期_时间_序号.bak；修改后的文件自动使用原来的 bigfile0.viv 名称。备份不覆盖旧备份。暂存输出请与原文件位于同一磁盘。\r\n\r\n"
   L"【三、仅另存修改版】\r\n取消勾选“自动备份并安装”，程序只生成输出路径指定的文件，原文件不改名。你可以自行备份后将生成文件改名为 bigfile0.viv，再放回对应盘的游戏目录。\r\n\r\n"
   L"【四、两张盘】\r\nDisc 1、Disc 2 必须分别选择各自完整的 bigfile0.viv 并执行一次。它们的目标资源相同，但整份 VIV 不可互相覆盖。\r\n\r\n"
   L"【五、实机查看】\r\n使用修改后文件，保持 English。原 new game 菜单应显示“新游戏”；带 // 的条目保留原有装饰。不含测试字样。其他文字暂时仍为原文。临时借用原西里尔字形槽，不适用于俄语界面。\r\n\r\n"
   L"【六、恢复原版】\r\n关闭游戏，先将当前修改版另行改名保留，再把对应的 .original.日期_时间_序号.bak 改回 bigfile0.viv。不要选错光盘，也不要删除原始备份。\r\n\r\n"
   L"【七、错误与取消】\r\n找不到完全匹配资源、发现多个相同资源、输出已存在或补丁已安装时，程序会停止。扫描和复制阶段可取消，原文件不受影响。自动改名与替换阶段若失败，会尝试恢复原名；请按错误提示检查备份位置。已生成的修改文件有可能保留用于检查。\r\n\r\n"
   L"【八、完整汉化后续范围】\r\n现已导出 6894 条全局文本索引，但尚未完成全文翻译、扩展中文字库、全部资源覆盖检查和两盘实机测试。完成版可能需要处理变长资源与 VIV 索引，不能以当前等长合并成功替代这些验证。\r\n\r\n"
   L"【验证限制】\r\n合并引擎已完成构造数据验证和原文件保护检查。用户截图已确认旧版“新游戏”显示有效；本版新增的界面和自动安装仍需 Windows 验证。\r\n");return 0;
 case WM_COMMAND:switch(LOWORD(wp)){
  case 101:choosein();break;case 102:chooseout();break;
  case 103:GetWindowTextW(inbox,inputpath,32768);GetWindowTextW(outbox,outputpath,32768);
   if(!*inputpath||!*outputpath){MessageBoxW(w,L"请先选择原始 VIV 和输出位置。",L"选择文件",MB_OK);break;}
   auto_install=SendMessageW(autobox,BM_GETCHECK,0,0)==BST_CHECKED;InterlockedExchange(&stopflag,0);setbusy(1);SendMessageW(bar,PBM_SETPOS,0,0);SetWindowTextW(statusbox,L"开始检查资源…");
   HANDLE t=CreateThread(NULL,0,worker,NULL,0,NULL);if(t)CloseHandle(t);else{setbusy(0);MessageBoxW(w,L"无法启动工作线程。",L"错误",MB_ICONERROR);}break;
  case 104:InterlockedExchange(&stopflag,1);SetWindowTextW(statusbox,L"正在取消，请稍候…");break;}return 0;
 case WM_STAGE:if(busy){SendMessageW(bar,PBM_SETPOS,lp,0);SetWindowTextW(statusbox,stages[wp<3?wp:0]);}return 0;
 case WM_DONE:{setbusy(0);wchar_t*e=(wchar_t*)lp;if(wp){
   SendMessageW(bar,PBM_SETPOS,100,0);wchar_t text[4096];
   if(auto_install){SetWindowTextW(statusbox,L"合并并安装成功。原文件已自动改名备份。");swprintf(text,4096,L"合并并安装成功。\n当前文件：\n%ls\n\n原版备份：\n%ls\n\n游戏菜单应显示“新游戏”。此版仍非完整汉化。",inputpath,backup_path);}
   else{SetWindowTextW(statusbox,L"合并成功。原文件保持原名，修改版已另存。");swprintf(text,4096,L"已生成：\n%ls\n\n请按界面说明备份并替换对应盘文件。此版仍非完整汉化。",outputpath);}
   MessageBoxW(w,text,L"完成",MB_OK|MB_ICONINFORMATION);
  }else{SetWindowTextW(statusbox,e);MessageBoxW(w,e,L"操作未完成",MB_OK|MB_ICONERROR);}free(e);return 0;}
 case WM_CLOSE:if(busy){InterlockedExchange(&stopflag,1);SetWindowTextW(statusbox,L"正在取消，完成后可关闭窗口。");}else DestroyWindow(w);return 0;
 case WM_DESTROY:PostQuitMessage(0);return 0;
 }return DefWindowProcW(w,msg,wp,lp);}
int WINAPI wWinMain(HINSTANCE h,HINSTANCE prev,LPWSTR cmd,int show){INITCOMMONCONTROLSEX ic={sizeof(ic),ICC_PROGRESS_CLASS};InitCommonControlsEx(&ic);SetProcessDPIAware();WNDCLASSW wc={0};wc.lpfnWndProc=proc;wc.hInstance=h;wc.lpszClassName=L"DS2VivMerge";wc.hCursor=LoadCursor(NULL,IDC_ARROW);wc.hbrBackground=(HBRUSH)(COLOR_BTNFACE+1);RegisterClassW(&wc);HWND w=CreateWindowW(wc.lpszClassName,L"Switch 死亡空间2 xbox360版 汉化工具",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,800,700,NULL,NULL,h,NULL);ShowWindow(w,show);MSG m;while(GetMessageW(&m,NULL,0,0)>0){TranslateMessage(&m);DispatchMessageW(&m);}return 0;}
