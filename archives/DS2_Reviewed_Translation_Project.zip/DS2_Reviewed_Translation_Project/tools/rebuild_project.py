"""Rebuild the editable LH2 translation project; standard Python 3 only."""
from pathlib import Path
import argparse,json,re,sys
from lh2_text import rebuild,parse
root=Path(__file__).resolve().parents[1];td=root/'translation'
a=argparse.ArgumentParser(description=__doc__);a.add_argument('--apply-reviewed-batches',action='store_true',help='Overwrite matching JSON translations using the reviewed batch files.');args=a.parse_args()
rows=json.loads((td/'zh_CN_working.json').read_text(encoding='utf-8-sig'))
if args.apply_reviewed_batches:
 updates={}
 for path in sorted(td.glob('reviewed_batch*.json')):updates.update(json.loads(path.read_text(encoding='utf8')))
 for row in rows:
  if row['id'] in updates:
   value=updates[row['id']];tokens=re.findall(r'\\+n',row['source'])
   if tokens:value=re.sub(r'\\+n',lambda m:tokens[0],value)
   row['translation']=value;row['review_status']='source_checked_translation'
for row in rows:
 text=row.get('translation') or row['source']
 if re.findall(r'\\+n',text)!=re.findall(r'\\+n',row['source']):raise ValueError('Newline tokens changed: '+row['id'])
 if sorted(re.findall(r'<[^>]+>',text))!=sorted(re.findall(r'<[^>]+>',row['source'])):raise ValueError('Markup changed: '+row['id'])
original=(td/'english_original.lh2').read_bytes();result=rebuild(original,rows)
assert rebuild(original,parse(original))==original
assert len(parse(result))==len(rows)
if args.apply_reviewed_batches:(td/'zh_CN_working.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
(td/'zh_CN_working.lh2').write_bytes(result)
print('OK:',len(rows),'entries;',len(result),'bytes;',td/'zh_CN_working.lh2')
