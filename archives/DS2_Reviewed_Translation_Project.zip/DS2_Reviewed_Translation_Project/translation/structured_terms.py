"""Source-bounded translations for item labels and exact UI sentence templates."""
import re,json
from pathlib import Path
terms={
'plasma cutter':'等离子切割枪','pulse rifle':'脉冲步枪','javelin gun':'标枪枪','ripper':'切割锯','flamethrower':'火焰喷射器','flame thrower':'火焰喷射器','force gun':'冲击枪','contact beam':'接触光束枪','line gun':'线形枪','seeker rifle':'追踪步枪','detonator':'引爆枪','detonator gun':'引爆枪','rivet gun':'铆钉枪',
'plasma energy':'等离子能量','plasma ammo':'等离子弹药','pulse rounds':'脉冲弹药','javelin spears':'标枪弹','javelin spear':'标枪弹','ripper blades':'切割锯片','ripper energy':'切割锯能量','flame fuel':'火焰燃料','force energy':'冲击能量','contact energy':'接触能量','line racks':'线形弹药','seeker shells':'追踪步枪弹','detonator mines':'引爆地雷','detonator mine':'引爆地雷','rivet bolts':'铆钉弹',
'stasis pack':'静滞能量包','power node':'能量节点','small med pack':'小型医疗包','medium med pack':'中型医疗包','large med pack':'大型医疗包','small air can':'小型氧气罐','medium air can':'中型氧气罐','large air can':'大型氧气罐',
'engineering suit':'工程师防护服','security suit':'安保防护服','vintage suit':'复古防护服','advanced suit':'高级防护服','engineering elite suit':'精英工程师防护服','security elite suit':'精英安保防护服','vintage elite suit':'精英复古防护服','advanced elite suit':'精英高级防护服','hacker suit':'黑客防护服','hacker contact beam':'黑客接触光束枪','soldier suit':'士兵防护服','riot security suit':'防暴安保防护服','arctic security suit':'极地安保防护服','earthgov security suit':'地球政府安保防护服','patrol suit':'巡逻防护服','shockpoint suit':'跃迁防护服','mp suit':'多人模式防护服',
'spitter':'喷吐者','puker':'呕吐者','lurker':'潜伏者','pack':'幼体群','slasher':'撕裂者','stasis':'静滞','health':'生命值','damage':'伤害','capacity':'容量','duration':'持续时间','reload':'装填速度','speed':'速度','weapon damage':'武器伤害','stasis energy':'静滞能量','melee damage':'近战伤害','paired damage':'协同伤害','magazine size':'弹匣容量'
}
prefixes={'forged':'锻造','bloody':'血腥','heavy duty':'重型','hazard':'危害','patrol':'巡逻','agility':'敏捷','triage':'急救','hacker':'黑客','zealot':'狂热者','shock':'冲击','earthgov':'地球政府'}
def item(t):
 t=t.strip().lower()
 if t in terms:return terms[t]
 for suffix in [' iii',' ii',' i']:
  if t.endswith(suffix) and t[:-len(suffix)] in terms:return terms[t[:-len(suffix)]]+suffix.upper()
 if t.endswith(' schematic'):
  x=item(t[:-10]);return x+'设计图' if x else None
 for p,zh in sorted(prefixes.items(),key=lambda x:-len(x[0])):
  if t.startswith(p+' '):
   x=item(t[len(p)+1:]);return zh+x if x else None
 return None

def translate(s):
 lead=s[:len(s)-len(s.lstrip())];trail=s[len(s.rstrip()):];t=s.strip();low=t.lower()
 x=item(t)
 if x:return lead+x+trail
 m=re.fullmatch(r'(Chapter|CHAPTER)\s+(\d+)',t)
 if m:return '第 '+str(int(m[2]))+' 章'
 m=re.fullmatch(r'LEVEL\s+(\d+)',t)
 if m:return '等级 '+str(int(m[1]))
 m=re.fullmatch(r'Unlocked at level (\d+)',t,re.I)
 if m:return '等级 '+m[1]+' 时解锁'
 m=re.fullmatch(r'unlock at level (\{[^}]+\})',t,re.I)
 if m:return '等级 '+m[1]+' 时解锁'
 m=re.fullmatch(r'Bring this schematic to the store to unlock the (.+)\.',t,re.I)
 if m:
  x=item(m[1]);return '将这份设计图带到商店，即可解锁'+x+'。' if x else None
 m=re.fullmatch(r'(.+?)(\\+n)Schematic Acquired\2Download at the Store',t,re.I)
 if m:
  x=item(m[1]);return x+m[2]+'已获得设计图'+m[2]+'请前往商店下载' if x else None
 m=re.fullmatch(r'You unlocked increased (.+?) for the (.+)',t,re.I)
 if m:
  prop=terms.get(m[1].lower());target=item(m[2]);return '已解锁'+target+'的'+prop+'提升' if prop and target else None
 m=re.fullmatch(r'increased (.+)',t,re.I)
 if m:
  x=terms.get(m[1].lower());return x+'提升' if x else None
 m=re.fullmatch(r'You unlocked additional Stasis energy',t,re.I)
 if m:return '已解锁额外静滞能量'
 return None

if __name__=='__main__':
 r=json.load(open('work/translation/zh_CN_working.json'));d={}
 for x in r:
  if not x['translation']:
   z=translate(x['source'])
   if z:d[x['id']]=z
 Path('work/translation/reviewed_batch02.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');print('Source-bounded labels/templates:',len(d))
