from pathlib import Path
import json,re
r=json.load(open('work/translation/zh_CN_working.json'));d={}
# These contiguous credit-name groups were inspected in source order.
starts=set('0334C6F5 095DA6F3 15984774 19B26923 1B093508 1C0D1A63 1C13BE61 1E14AF1F 20CE5039 23484503 24871361 27C4982B 2A021C46 2AFE395F 2C8F5D11 2EC4EC52 31C19597 3298E2C7 3299E306 329AE345 329BE386 329CE3C3 329DE402 38F01DB7 399207A9 3AD35835 417EB654 41FFA0A7 485974E6 48D3791E 4D2264DC 504F40AB 522AA0AE 597F9444 5D6CAFC8 5F3DD1C9 6052D254 6053D293 615EF08D 618C72C5 619A7182 62394F7C 6BE61F0B 6D462465 71C691A6 71F46D1E 72CAF56A 72CBF5A9 7847C107 7AA2F4B5 7D0BA840 7F1A1A2E 82903367 86E0AEFF 8AD12835 8E4472D2 8F66ECAA 9DE52B75 A4732CFD AD45AC6A B5DACF24 B9046191 BA48453A CCB815EC D033BAED D3AEBA03 D562A93F DC4C0D28 DC4D0D67 EDBE340C EE9F9A5A F39C8F09 F39C8F0D F3CBFBED FA3381A3 FAA94A5D FDC170E3 FF06AFE2'.split())
lookup={int(x['id'],16):x for x in r}
for start in starts:
 k=int(start,16)
 while k in lookup:
  x=lookup[k];s=x['source'].strip()
  if x['translation'] or not re.fullmatch(r"[A-ZÀ-Ž][A-Za-zÀ-ž’'\-.]+(?: [A-ZÀ-Ž][A-Za-zÀ-ž’'\-.]+){1,4}",s):break
  d[x['id']]=x['source'];k+=1
for x in r:
 if x['translation']:continue
 s=x['source'];t=s.strip()
 if not re.search(r'[A-Za-z\u3400-\u9fff\u0400-\u04ff]',t):d[x['id']]=s
 elif re.fullmatch(r'(?:Credits_|video_log_|audio_log_)[\w_]+',t):d[x['id']]=s
 elif re.fullmatch(r'\[(?:c=[^\]]+|(?i:menu[ab]|[lr]s(?:top|bottom)|[lr]d(?:up|down|left|right)|[lr]stick3?|select|start))\]',t):d[x['id']]=s
 elif re.fullmatch(r'\d+\s*x\s*\d+(?:,?\s*\d+Hz)?',t,re.I):d[x['id']]=s
 elif len(t)==1 and t.isascii():d[x['id']]=s
Path('work/translation/reviewed_batch07.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');print('Explicit original-preservation rows:',len(d))
