from pathlib import Path
import runpy,sys
sys.argv=[str(Path(__file__).resolve().parents[1]/'tools/rebuild_project.py'),'--apply-reviewed-batches']
runpy.run_path(sys.argv[0],run_name='__main__')
