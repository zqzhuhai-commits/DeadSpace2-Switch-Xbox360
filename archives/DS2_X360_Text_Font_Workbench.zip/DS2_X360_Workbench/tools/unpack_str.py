from pathlib import Path
import ctypes,struct,zipfile,json
L=ctypes.CDLL(str((Path(__file__).resolve().parent/'mspack/lzx.so').resolve()));L.decode.argtypes=[ctypes.c_char_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_int,ctypes.c_int]
def unpack_xmem(z):
 pos=0;blocks=[];total=0
 while pos<len(z):
  if z[pos:pos+2]==b'\0\0':break
  if z[pos]==255:
   size=int.from_bytes(z[pos+1:pos+3],'big');n=int.from_bytes(z[pos+3:pos+5],'big');pos+=5
  else:size=32768;n=int.from_bytes(z[pos:pos+2],'big');pos+=2
  if n==0:break
  if pos+n>len(z):raise ValueError('XMem framing overrun')
  blocks.append(z[pos:pos+n]);total+=size;pos+=n
 raw=b''.join(blocks);out=ctypes.create_string_buffer(total);r=L.decode(raw,len(raw),out,total,17)
 if r:raise ValueError(f'LZX error {r}')
 return out.raw

def unpack(p,dest):
 dest=Path(dest);dest.mkdir(parents=True,exist_ok=True);pos=12;resources=[];current=None
 def flush():
  if current is not None:
   b=b''.join(current['parts']);n=current['size'];current['decoded_size']=len(b)
   if len(b)<n:raise ValueError(f'Truncated {current["path"]}: {len(b)} < {n}')
   f=dest/Path(current['path'].replace('\\','/')).name;f.write_bytes(b[:n]);current['output']=str(f);del current['parts'];resources.append(current.copy())
 while pos+12<=len(p):
  if p[pos:pos+4]==b'FILL':
   pos+=int.from_bytes(p[pos+4:pos+8],'big');continue
  if p[pos:pos+4]!=b'SHOC':
   nxt=((pos//0x20000)+1)*0x20000
   if p[pos:pos+4] != b'\0'*4:raise ValueError(f'Unexpected bytes at {pos:x}')
   pos=nxt;continue
  n=int.from_bytes(p[pos+4:pos+8],'big');tag=p[pos+8:pos+12];end=pos+n
  if n<12 or end>len(p):raise ValueError('Bad chunk size')
  if tag==b'SHDR':
   flush();name,path=p[pos+44:end].split(b'\0')[:2];current={'path':path.decode('ascii'),'size':int.from_bytes(p[pos+40:pos+44],'big'),'parts':[]}
  elif tag==b'LZXD':
   zsize=int.from_bytes(p[pos+12:pos+16],'big');current['parts'].append(unpack_xmem(p[pos+16:pos+16+zsize]))
  elif tag==b'SDAT':current['parts'].append(p[pos+12:end])
  else:raise ValueError(f'Unknown chunk {tag}')
  pos=end
 flush();return resources
if __name__=='__main__':
 import argparse
 a=argparse.ArgumentParser();a.add_argument('input');a.add_argument('output_directory');v=a.parse_args()
 r=unpack(Path(v.input).read_bytes(),v.output_directory)
 Path(v.output_directory,'manifest.json').write_text(json.dumps(r,indent=2))
 print('Extracted',len(r),'resources')
