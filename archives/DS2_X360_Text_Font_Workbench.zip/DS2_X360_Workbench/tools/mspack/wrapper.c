#include <stdlib.h>
#include <string.h>
#include "mspack.h"
#include "lzx.h"
struct mem {unsigned char *p; int size,pos;};
static int rd(struct mspack_file *f,void *b,int n){struct mem*m=(void*)f;if(n>m->size-m->pos)n=m->size-m->pos;memcpy(b,m->p+m->pos,n);m->pos+=n;return n;}
static int wr(struct mspack_file *f,void *b,int n){struct mem*m=(void*)f;if(n>m->size-m->pos)return -1;memcpy(m->p+m->pos,b,n);m->pos+=n;return n;}
static void* al(struct mspack_system*s,size_t n){return malloc(n);}
static void cp(void*s,void*d,size_t n){memcpy(d,s,n);}
int decode(unsigned char*in,int insize,unsigned char*out,int outsize,int bits){
 struct mspack_system sys={0};sys.read=rd;sys.write=wr;sys.alloc=al;sys.free=free;sys.copy=cp;
 struct mem i={in,insize,0},o={out,outsize,0};
 struct lzxd_stream*l=lzxd_init(&sys,(void*)&i,(void*)&o,bits,0,4096,outsize,0);if(!l)return -99;
 int r=lzxd_decompress(l,outsize);lzxd_free(l);return r;
}
