死亡空间2 Xbox 360 汉化工作包（阶段成果，非游戏补丁）

已验证：
1. Disc 1 与 Disc 2 提供的语言资源、字体 STR/TOC、语言配置逐字节一致。
2. 8CA715C3 中的 deadspace2_global.en.lh2 已完整解压，大小 351220 字节。
3. 6894 条文本都是有效 UTF-8，ID 与字符串偏移使用大端整数。
4. 不改译文的导出/重建与原始 LH2 逐字节一致。
5. 中文初稿覆盖 264 条索引；其余 translation 为空，重建时保留原文。
6. 中文初稿重建后可以再次解析；这仅是文件结构验证，尚未经过游戏测试。
7. 字体 STR 另拆出 518 项资源，其中 15 项是五组字体的 inf/tg4h/tg4d。
   另有 501 项 tox.xen 字幕资源、2 项辅助资源。字体描述未发现 CJK 字形。

目录：
texts/english_original.lh2     解压后的完整英文原件，不是可直接替换的 8CA715C3。
texts/english_export.json      全部原文、ID、偏移。
texts/zh_CN_draft.json         部分中文初稿，尚未完成全文翻译与术语校对。
resources/                    解出的字体、字幕及辅助数据，均未修改。
font_codepoints.json          根据 24 字节字形记录读取的码点，用于后续字体分析。
validation.json               已执行的验证与尚未完成的项目。
tools/lh2_text.py              纯 Python 3 文本导出/重建工具，无第三方依赖。
tools/unpack_str.py            原始 ols3/SHOC 容器拆解工具（Linux，需编译 LZX 解码器）。
tools/mspack/                  libmspack 源码与 LGPL 2.1 许可证，另含本次编写的 wrapper.c。

文本重建命令（在本包目录执行，安装 Python 3）：
python tools/lh2_text.py rebuild texts/english_original.lh2 texts/zh_CN_draft.json texts/zh_CN_draft.lh2

重新导出命令：
python tools/lh2_text.py export texts/english_original.lh2 texts/new_export.json

编辑规则：
仅修改 translation，不要改 index、id、source，不要删除或重排条目。
保留 [MenuA]、{n}、%g、%1 等控制符。工具会检查此类标记。
保留原文的换行控制符。空 translation 表示保留原文。
部分界面词语存在上下文歧义，初稿仍需结合实际画面校对。

Linux 编译解码器（GCC）：
gcc -shared -fPIC -O2 -I tools/mspack tools/mspack/lzxd.c tools/mspack/wrapper.c -o tools/mspack/lzx.so
python tools/unpack_str.py 原始STR文件 输出目录

当前限制与后续步骤：
尚未完成中文字形贴图、字符映射和 Xbox 360 纹理布局的重建。
尚未实现修改后资源的 LZX 压缩、SHOC 回封、STR/TOC 与 VIV 索引更新。
尚未完成其余文本翻译；这些全局资源不等于已确认覆盖整部游戏所有文本。
未进行 Xbox 360 或模拟器运行测试。本包不能直接用于游戏覆盖安装。
不要将解压后的 LH2 改名为 8CA715C3 后覆盖，它们的容器结构不同。

解码器来源：https://github.com/kyz/libmspack （LGPL 2.1，见 COPYING.LIB）
容器格式参考：Luigi Auriemma 的 dead_space_3.bms 脚本。
