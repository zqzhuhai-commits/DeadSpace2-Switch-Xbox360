"""Dead Space 2 Xbox 360 equal-length resource merger. Python 3.9+, standard library."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, threading, queue, sys

ROOT = Path(__file__).resolve().parent
CHUNK = 8 * 1024 * 1024

class MergeError(Exception): pass
class Cancelled(MergeError): pass

def digest(b): return hashlib.sha256(b).hexdigest()
def check_cancel(cancel):
    if cancel and cancel.is_set(): raise Cancelled('操作已取消，原始 VIV 未修改。')

def load_payload(root=ROOT):
    rows=json.loads((Path(root)/'payload/manifest.json').read_text(encoding='utf-8'))
    result=[]
    if len(rows)!=2: raise MergeError('补丁清单不完整。')
    for row in rows:
        row=dict(row)
        for kind in ['original','new']:
            name=row[kind+'_file']
            if Path(name).name!=name: raise MergeError('补丁路径无效。')
            b=(Path(root)/'payload'/name).read_bytes()
            if len(b)!=row['size'] or digest(b)!=row[kind+'_sha256']:
                raise MergeError('补丁数据校验失败：'+name)
            row[kind]=b
        # Original and rebuilt resources have the same header prefix.
        row['anchors']=list(dict.fromkeys([row['original'][:64],row['new'][:64]]))
        result.append(row)
    return result

def identity(p):
    s=Path(p).stat(); return (s.st_size,s.st_mtime_ns,s.st_ino,s.st_dev)

def scan(source, payload, progress=lambda *x:None, cancel=None):
    source=Path(source); before=identity(source); total=before[0]
    found=[{} for _ in payload]; overlap=max(len(a) for r in payload for a in r['anchors'])-1
    done=0; tail=b''
    with source.open('rb') as stream, source.open('rb') as verify:
        while True:
            check_cancel(cancel); block=stream.read(CHUNK)
            if not block: break
            data=tail+block; base=done-len(tail)
            for idx,row in enumerate(payload):
                for anchor in row['anchors']:
                    pos=0
                    while True:
                        pos=data.find(anchor,pos)
                        if pos<0: break
                        offset=base+pos; pos+=1
                        if offset in found[idx] or offset+row['size']>total: continue
                        verify.seek(offset); h=digest(verify.read(row['size']))
                        if h==row['original_sha256']: found[idx][offset]='original'
                        elif h==row['new_sha256']: found[idx][offset]='new'
            done+=len(block); tail=data[-overlap:]; progress('扫描资源',done,total)
    if identity(source)!=before: raise MergeError('扫描过程中源文件发生变化，请关闭其他修改工具后重试。')
    matches=[]
    for row,hits in zip(payload,found):
        if not hits: raise MergeError('找不到完全匹配的资源：'+row['name']+'。请选择与上传资源一致的原始 bigfile0.viv；其他版本或已修改版本不支持。')
        if len(hits)!=1: raise MergeError('资源存在多个完全匹配的位置：'+row['name']+'。为避免改错，已停止。')
        offset,state=next(iter(hits.items()));matches.append({'row':row,'offset':offset,'state':state})
    matches.sort(key=lambda x:x['offset'])
    for a,b in zip(matches,matches[1:]):
        if a['offset']+a['row']['size']>b['offset']: raise MergeError('目标资源范围重叠，已停止。')
    return matches,before

def merge(source, destination, progress=lambda *x:None, cancel=None, root=ROOT):
    source=Path(source).resolve();destination=Path(destination).resolve()
    if not source.is_file(): raise MergeError('请选择存在的 VIV 文件。')
    if source==destination: raise MergeError('输出路径不能与原文件相同。')
    if destination.exists(): raise MergeError('输出文件已存在，请选择新的文件名。')
    if not destination.parent.is_dir(): raise MergeError('输出目录不存在。')
    payload=load_payload(root);matches,before=scan(source,payload,progress,cancel)
    if all(m['state']=='new' for m in matches): raise MergeError('这个 VIV 已包含本版“新游戏”修改，无需再次合并。')
    if shutil.disk_usage(destination.parent).free<before[0]+1024*1024:
        raise MergeError('输出目录的可用空间不足，需要至少容纳一份完整 VIV。')
    temp=Path(str(destination)+'.partial');owned=False
    try:
        # Exclusive creation prevents overwriting a previous incomplete file.
        with temp.open('xb') as out:
            owned=True
            with source.open('rb') as inp:
                done=0
                while True:
                    check_cancel(cancel);b=inp.read(CHUNK)
                    if not b:break
                    out.write(b);done+=len(b);progress('复制原始 VIV',done,before[0])
            if done!=before[0] or identity(source)!=before: raise MergeError('复制过程中源文件发生变化，输出已作废。')
            for m in matches:
                check_cancel(cancel);out.seek(m['offset']);out.write(m['row']['new'])
            out.flush();os.fsync(out.fileno())
        with temp.open('rb') as f:
            if temp.stat().st_size!=before[0]: raise MergeError('输出文件大小不匹配。')
            for m in matches:
                f.seek(m['offset'])
                if digest(f.read(m['row']['size']))!=m['row']['new_sha256']:raise MergeError('输出资源校验失败。')
        check_cancel(cancel)
        # Publish without replacing an existing destination, including a racing creation.
        if os.name=='nt': os.rename(temp,destination)
        else:
            os.link(temp,destination);temp.unlink()
        owned=False
        return {'input':str(source),'output':str(destination),'bytes':before[0],
                'display_text':'新游戏','original_preserved':True,
                'resources':[{'name':m['row']['name'],'offset':m['offset'],'size':m['row']['size'],
                              'previous_state':m['state'],'sha256':m['row']['new_sha256']} for m in matches]}
    finally:
        if owned:
            try:temp.unlink()
            except OSError:pass

def gui():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
    window=tk.Tk();window.title('死亡空间2 · VIV 资源合并');window.geometry('700x430');window.minsize(650,400)
    window.configure(bg='#f5f6f8');style=ttk.Style();style.theme_use('clam')
    box=ttk.Frame(window,padding=22);box.pack(fill='both',expand=True)
    ttk.Label(box,text='死亡空间2 · VIV 资源合并',font=('Microsoft YaHei UI',18,'bold')).pack(anchor='w')
    ttk.Label(box,text='内置菜单：新游戏　｜　另存完整 VIV，保留原文件',font=('Microsoft YaHei UI',10)).pack(anchor='w',pady=(8,20))
    source=tk.StringVar();target=tk.StringVar();busy=[False];cancel=threading.Event();messages=queue.Queue()
    def browse_in():
        p=filedialog.askopenfilename(title='选择原始 bigfile0.viv',filetypes=[('VIV 文件','*.viv'),('所有文件','*.*')])
        if p:
            source.set(p);a=Path(p);target.set(str(a.with_name(a.stem+'_zh'+a.suffix)))
    def browse_out():
        p=filedialog.asksaveasfilename(title='另存修改后的 VIV',defaultextension='.viv',initialfile='bigfile0_zh.viv',filetypes=[('VIV 文件','*.viv')])
        if p:target.set(p)
    controls=[]
    for title,var,callback in [('原始 VIV',source,browse_in),('输出 VIV',target,browse_out)]:
        ttk.Label(box,text=title).pack(anchor='w');row=ttk.Frame(box);row.pack(fill='x',pady=(4,12));entry=ttk.Entry(row,textvariable=var);entry.pack(side='left',fill='x',expand=True);button=ttk.Button(row,text='选择…',command=callback);button.pack(side='right',padx=(8,0));controls.extend([entry,button])
    bar=ttk.Progressbar(box,maximum=100);bar.pack(fill='x',pady=(4,8));status=tk.StringVar(value='请选择与上传资源一致的 Disc 1 或 Disc 2 原始 VIV。');ttk.Label(box,textvariable=status,wraplength=630).pack(anchor='w')
    actions=ttk.Frame(box);actions.pack(fill='x',pady=(20,8))
    def progress(stage,done,total): messages.put(('progress',(stage,done,total)))
    def worker(src,dst):
        try:messages.put(('done',merge(src,dst,progress,cancel)))
        except Exception as e:messages.put(('error',str(e)))
    def start():
        if not source.get() or not target.get():messagebox.showinfo('选择文件','请先选择原始 VIV 和输出位置。');return
        busy[0]=True;cancel.clear();bar['value']=0
        for c in controls+[startbutton]:c.configure(state='disabled')
        cancelbutton.configure(state='normal');status.set('正在检查补丁数据…')
        threading.Thread(target=worker,args=(source.get(),target.get()),daemon=True).start()
    startbutton=ttk.Button(actions,text='合并并另存 VIV',command=start);startbutton.pack(side='left')
    cancelbutton=ttk.Button(actions,text='取消',command=cancel.set,state='disabled');cancelbutton.pack(side='left',padx=10)
    ttk.Label(box,text='仅修改菜单与对应字形；不是完整汉化。合并成功后仍需实机验证。',wraplength=630).pack(anchor='w')
    def poll():
        # Drain queued progress and render only the newest item per UI tick.
        latest=None
        while True:
            try:kind,data=messages.get_nowait()
            except queue.Empty:break
            if kind=='progress':latest=data;continue
            latest=None;busy[0]=False
            for c in controls+[startbutton]:c.configure(state='normal')
            cancelbutton.configure(state='disabled')
            if kind=='error':status.set(data);messagebox.showerror('未生成输出文件',data)
            else:
                bar['value']=100;status.set('合并成功。原文件已保留。')
                text='已生成：\n'+data['output']+'\n\n将它改名为 bigfile0.viv，替换对应盘的原文件。\n菜单应显示“新游戏”。请保留原版备份。'
                try:Path(data['output']+'.merge.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
                except OSError:text+='\n校验记录未能保存，VIV 文件已经生成。'
                messagebox.showinfo('合并成功',text)
        if latest and busy[0]:
            stage,done,total=latest;bar['value']=100*done/max(total,1);status.set('%s：%.1f%%（%.0f / %.0f MB）'%(stage,100*done/max(total,1),done/1048576,total/1048576))
        window.after(100,poll)
    def close():
        if busy[0]:cancel.set();status.set('正在取消，请稍候…')
        else:window.destroy()
    window.protocol('WM_DELETE_WINDOW',close);poll();window.mainloop()

if __name__=='__main__':
    if len(sys.argv)==1:gui()
    else:
        a=argparse.ArgumentParser(description=__doc__);a.add_argument('source');a.add_argument('output');v=a.parse_args()
        try:print(json.dumps(merge(v.source,v.output),ensure_ascii=False,indent=2))
        except Exception as e:print(str(e),file=sys.stderr);sys.exit(1)
